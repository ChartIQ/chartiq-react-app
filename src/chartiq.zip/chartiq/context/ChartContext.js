import React from 'react'

export const ChartContext = React.createContext({})
