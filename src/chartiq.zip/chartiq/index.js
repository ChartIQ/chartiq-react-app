import 'chartiq/js/thirdparty/perfect-scrollbar.jquery.js';

import 'chartiq/js/chartiq';
import 'chartiq/js/addOns';

export { default as AdvancedChart } from './containers/AdvancedChart';
export { default as defaultConfig, getDefaultConfig } from './_config';
