import 'chartiq/css/normalize.css';
import 'chartiq/css/page-defaults.css';
import 'chartiq/css/perfect-scrollbar.css';
import 'chartiq/css/stx-chart.css';
import 'chartiq/css/chartiq.css';
// Remove this file if you don't want the helicopter marker
import './chartiq-abstract-marker.css';

// This file must be loaded last after default ChartIQ!
import './chartiq-react-components.css';
